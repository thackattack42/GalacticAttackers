# RedScreen

A Vulkan Template for Windows/Mac/Linux.

*All platforms require you to download & install the Vulkan API.
Linux also requires X11. See "Gateware/README.md" for more details.*

*if you want to start adding additional libraries be sure to check 
"Gateware/README.md" for what additional dependencies you may need*

